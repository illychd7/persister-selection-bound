"""Exact down-sampling (thinning) of UMI counts."""
import numpy as np, scipy.sparse as sp

def thin(X, T, rng):
    """Multivariate-hypergeometric down-sampling of every row of integer matrix X to total T."""
    X = X.tocsr().astype(np.int64)
    data = np.empty_like(X.data)
    for i in range(X.shape[0]):
        a, b = X.indptr[i], X.indptr[i + 1]
        data[a:b] = rng.multivariate_hypergeometric(X.data[a:b], T, method="marginals")
    Y = sp.csr_matrix((data, X.indices.copy(), X.indptr.copy()), shape=X.shape)
    Y.eliminate_zeros()
    return Y
