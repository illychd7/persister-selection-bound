#!/usr/bin/env python3
"""Survival budgets (Proposition 2.4) from the digitised live-imaging lineages of Oren et al. (bioRxiv 2020, Fig. 1b).
Input: data/derived/fig1b_digitized.npz (produced by digitize_fig1b.py from the preprint figure).
Upper budget = 2^(max divisions) / fraction of lineages alive; proxy = max / mean of 2^(divisions), dead lineages = 0."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import json, numpy as np
from config import DERIVED, RES
z = np.load(DERIVED / "fig1b_digitized.npz")
A, D, days = z["A"], z["D"], z["days"]
out = {}
for j, t in enumerate(days):
    fa = float(A[:, j].mean()); dmax = float(np.nanmax(D[:, j]))
    prog = np.where(A[:, j], 2.0 ** np.nan_to_num(D[:, j]), 0.0)
    out[int(t)] = dict(lineages=int(len(A)), alive=int(A[:, j].sum()), frac_alive=fa, max_divisions=dmax,
                       budget_upper=2 ** dmax / fa, budget_proxy=float(prog.max() / prog.mean()))
    print(t, {k: round(v, 3) if isinstance(v, float) else v for k, v in out[int(t)].items()})
json.dump(out, open(RES / "survival_budget.json", "w"), indent=1)
