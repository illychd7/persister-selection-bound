import gzip, sys, numpy as np, scipy.sparse as sp
src, out = sys.argv[1], sys.argv[2]
rows, cols, vals, genes = [], [], [], []
with gzip.open(src, "rt") as fh:
    hdr = [c.strip('"') for c in fh.readline().rstrip("\n").split(",")]
    cells = hdr[1:] if hdr[0] == "" else hdr
    for g, line in enumerate(fh):
        name, rest = line.split(",", 1)
        v = np.fromstring(rest, sep=",", dtype=np.float32)
        nz = np.nonzero(v)[0]
        genes.append(name.strip('"')); rows.append(np.full(len(nz), g, np.int32)); cols.append(nz.astype(np.int32)); vals.append(v[nz])
X = sp.csr_matrix((np.concatenate(vals), (np.concatenate(cols), np.concatenate(rows))), shape=(len(cells), len(genes)))
sp.save_npz(out + "_counts.npz", X)
open(out + "_genes.txt", "w").write("\n".join(genes)); open(out + "_cells.txt", "w").write("\n".join(cells))
print(X.shape, X.nnz, "integer:", bool(np.all(np.mod(X.data, 1) == 0)))
