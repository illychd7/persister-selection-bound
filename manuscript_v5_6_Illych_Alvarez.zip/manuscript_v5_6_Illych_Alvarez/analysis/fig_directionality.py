#!/usr/bin/env python3
"""Figure 7: forward (novelty) and reverse (loss) bounds for MAPK targets and FIT-selected up/down-regulated panels."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import json, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from config import RES, FIG
d = json.load(open(RES / "panel_direction_check.json"))
S = ["3_rep1", "3_rep2", "7_rep1", "14_rep1_high"]; L = ["d3 r1", "d3 r2", "d7 r1", "d14 high r1"]
C = {"MAPK12": "#2a78d6", "UP12_fit": "#1baf7a", "DOWN12_fit": "#6250d6"}
N = {"MAPK12": "MAPK targets (12)", "UP12_fit": "induced genes (12)", "DOWN12_fit": "repressed genes (12)"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": "#52514e", "xtick.color": "#52514e", "ytick.color": "#52514e", "pdf.fonttype": 42})
fig, ax = plt.subplots(figsize=(6.2, 3.9), dpi=200)
for k in ["MAPK12", "UP12_fit", "DOWN12_fit"]:
    ax.plot(range(4), [max(d[k][s]["novelty"], 1e-3) for s in S], "-o", color=C[k], ms=4, lw=1.4, label=N[k] + ", forward")
    ax.plot(range(4), [max(d[k][s]["loss"], 1e-3) for s in S], "--s", color=C[k], ms=4, lw=1.2, label=N[k] + ", reverse")
ax.axhline(1, color="#52514e", lw=.7, ls=":"); ax.set_yscale("log"); ax.set_xticks(range(4), L)
ax.set_ylabel("Lower bound $M_L$ (values below $10^{-3}$ drawn at $10^{-3}$)")
for s in ["top", "right"]: ax.spines[s].set_visible(False)
ax.grid(axis="y", color="#e4e3df", lw=.5); ax.legend(fontsize=6, frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.12))
fig.tight_layout(); fig.savefig(FIG / "fig_directionality.pdf"); fig.savefig(FIG / "fig_directionality.png")
