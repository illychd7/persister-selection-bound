#!/usr/bin/env python3
"""Appendix A: maximum attainable bound of the clone-cross-fitted design.
Input: data/derived/crossfit_response_ot_bounds.csv (bounds of the four response models on held-out clones).
Ceiling = Clopper-Pearson LB with all target cells in the tail / UB with no reference estimation cell in the tail,
at the joint level 0.05 / (2 x 4 samples x 2 folds x 4 models x 7 thresholds)."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd
from scipy.stats import beta
from config import DERIVED, RES
d = pd.read_csv(DERIVED / "crossfit_response_ot_bounds.csv"); a = 0.05 / (2 * 4 * 2 * 4 * 7)
rows = []
for (t, f), g in d.groupby(["target", "fold"]):
    r = g.iloc[0]; ceil = float(beta.ppf(a, int(r.n_target_cells), 1)) / float(beta.ppf(1 - a, 1, int(r.est)))
    row = dict(target=t, fold=int(f), n_ref_est=int(r.est), n_target=int(r.n_target_cells), ceiling=ceil)
    for m in ["identity", "translation", "affine", "ot_knn"]: row[m] = float(g[g.model == m].MLplus_joint95.iloc[0])
    rows.append(row)
pd.DataFrame(rows).to_csv(RES / "crossfit_power_ceiling.csv", index=False); print(pd.DataFrame(rows).round(2).to_string(index=False))
