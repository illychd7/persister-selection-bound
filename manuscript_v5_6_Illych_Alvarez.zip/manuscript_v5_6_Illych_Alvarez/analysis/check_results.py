#!/usr/bin/env python3
"""Compare regenerated results/ with the values reported in the manuscript (expected/)."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import json, numpy as np, pandas as pd
from config import RES, ROOT
EXP = ROOT / "expected"
def flat(x, pre=""):
    if isinstance(x, dict):
        for k, v in x.items(): yield from flat(v, f"{pre}/{k}")
    elif isinstance(x, list):
        for i, v in enumerate(x): yield from flat(v, f"{pre}[{i}]")
    elif isinstance(x, (int, float)) and not isinstance(x, bool): yield pre, float(x)
bad = 0
for e in sorted(EXP.iterdir()):
    r = RES / e.name
    if not r.exists(): print(f"MISSING  {e.name}"); bad += 1; continue
    if e.suffix == ".json":
        a, b = dict(flat(json.load(open(e)))), dict(flat(json.load(open(r))))
        keys = {k for k in set(a) & set(b) if '/time' not in k}   # run times are not results
        # MELD (graphtools) is not bit-reproducible across runs; its ratios vary by up to a few percent
        # without changing any decision (decisions are checked exactly in rejection_rates.csv).
        tol = lambda k: 0.05 if "meld" in k else 1e-6
        diff = [k for k in keys if not np.isclose(a[k], b[k], rtol=tol(k), atol=1e-9, equal_nan=True)]
        miss = set(a) - set(b)
    else:
        A, Bf = pd.read_csv(e), pd.read_csv(r); num = A.select_dtypes("number").columns
        diff = [c for c in num if c in Bf and not np.allclose(A[c], Bf[c], rtol=1e-6, equal_nan=True)]; miss = set(A.columns) - set(Bf.columns); keys = num
    ok = not diff and not miss
    bad += not ok
    print(f"{'OK      ' if ok else 'DIFFERS '} {e.name}  ({len(keys)} values compared{', ' + str(len(diff)) + ' differ' if diff else ''}{', ' + str(len(miss)) + ' missing' if miss else ''})")
    for k in list(diff)[:5]: print("          ", k)
print("\nAll results reproduced." if bad == 0 else f"\n{bad} file(s) differ or are missing.")
sys.exit(1 if bad else 0)
