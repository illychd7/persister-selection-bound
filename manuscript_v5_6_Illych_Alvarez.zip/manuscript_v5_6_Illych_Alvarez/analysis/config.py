"""Paths shared by all scripts. Everything is relative to the repository root."""
import pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"            # GEO files (downloaded by download_data.py)
PROC = ROOT / "data" / "processed"     # sparse matrices and preprocessed embeddings (generated)
DERIVED = ROOT / "data" / "derived"    # small derived inputs shipped with the repository
RES = ROOT / "results"                 # JSON / CSV outputs
FIG = ROOT / "figures"                 # PDF / PNG figures
for _d in (RAW, PROC, RES, FIG):
    _d.mkdir(parents=True, exist_ok=True)
PC9_COUNTS = RAW / "GSE150949_pc9_count_matrix.csv.gz"
PC9_META = RAW / "GSE150949_metaData_with_lineage.txt.gz"
POOLED_COUNTS = RAW / "GSE150949_pooled_watermelon.count.matrix.csv.gz"
POOLED_META = RAW / "GSE150949_pooled_watermelon.metadata.matrix.csv.gz"
