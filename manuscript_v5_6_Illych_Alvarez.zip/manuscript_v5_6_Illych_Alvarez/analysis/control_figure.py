"""Figure: where does M_L come from? Bound vs day 0 (and between replicate libraries) in different feature spaces."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from config import RAW, PROC, DERIVED, RES, FIG, PC9_META, POOLED_META
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
r = json.load(open(RES / "gene_panel_control.json")); d = json.load(open(RES / "panel_direction_check.json"))
TRE = ["3_rep1", "3_rep2", "7_rep1", "7_rep2", "14_rep1_low", "14_rep2_low", "14_rep1_med", "14_rep2_med", "14_rep1_high", "14_rep2_high"]
REP = ["3_rep1->3_rep2", "3_rep2->3_rep1", "7_rep1->7_rep2", "7_rep2->7_rep1", "14_rep1_low->14_rep2_low", "14_rep2_low->14_rep1_low",
       "14_rep1_med->14_rep2_med", "14_rep2_med->14_rep1_med", "14_rep1_high->14_rep2_high", "14_rep2_high->14_rep1_high"]
rows = [("2000 variable genes\n(20 PCs)", [r["HVG2000"][f"0->{s}"] for s in TRE], [r["HVG2000"][k] for k in REP]),
        ("Random 200 genes\n(expression-matched)", [r["RANDOM_matched_STABLE200"][s]["median"] for s in TRE], [r["RANDOM_matched_STABLE200"]["3_rep1->3_rep2"]["median"]]),
        ("Drug-stable 200 genes", [r["STABLE200"][f"0->{s}"] for s in TRE], [r["STABLE200"][k] for k in REP]),
        ("Technical covariates only\n(genes detected, mito fraction)", [r["TECH2"][f"0->{s}"] for s in TRE], [r["TECH2"][k] for k in REP]),
        ("Housekeeping 11\n(Eisenberg & Levanon)", [r["HK11"][f"0->{s}"] for s in TRE], [r["HK11"][k] for k in REP]),
        ("Random 11 genes\n(expression-matched)", [r["RANDOM_matched_HK11"][s]["median"] for s in TRE], [r["RANDOM_matched_HK11"]["3_rep1->3_rep2"]["median"]])]
C = dict(d3="#2a78d6", d7="#eb6834", d14="#1baf7a", rep="#8a8984", ink="#0b0b0b", ink2="#52514e", grid="#e4e3df")
col = lambda s: C["d3"] if s.startswith("3_") else C["d7"] if s.startswith("7_") else C["d14"]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": C["ink2"], "xtick.color": C["ink2"], "ytick.color": C["ink"]})
fig, ax = plt.subplots(figsize=(7.0, 4.7), dpi=200)
rng = np.random.default_rng(1)
for i, (lab, v0, vr) in enumerate(rows):
    y = len(rows) - 1 - i
    for s, v in zip(TRE, v0):
        ax.scatter(max(v, 0.3), y + 0.12 + rng.uniform(-0.05, 0.05), s=26, color=col(s), edgecolor="white", lw=0.8, zorder=3)
    for v in vr:
        ax.scatter(max(v, 0.3), y - 0.18 + rng.uniform(-0.04, 0.04), s=22, marker="s", color=C["rep"], edgecolor="white", lw=0.8, zorder=3)
ax.axvline(17.3, color=C["ink2"], lw=1, ls=(0, (3, 2)), zorder=1)
ax.text(17.3 * 1.06, len(rows) - 0.45, "day-3 selection budget\n(upper bound, 17.3)", fontsize=6.8, color=C["ink2"], va="top")
ax.axvline(1, color=C["grid"], lw=1, zorder=0)
ax.set_xscale("log"); ax.set_xlim(0.3, 400)
ax.set_yticks(range(len(rows)), [l for l, _, _ in rows][::-1])
ax.set_xlabel("Lower confidence bound $M_L$ (log scale)")
ax.grid(axis="x", color=C["grid"], lw=0.6); ax.set_axisbelow(True)
for s in ["top", "right"]: ax.spines[s].set_visible(False)
from matplotlib.lines import Line2D
h = [Line2D([], [], marker="o", ls="", color=C["d3"], label="day 3 vs day 0"), Line2D([], [], marker="o", ls="", color=C["d7"], label="day 7 vs day 0"),
     Line2D([], [], marker="o", ls="", color=C["d14"], label="day 14 vs day 0"), Line2D([], [], marker="s", ls="", color=C["rep"], label="replicate library vs replicate")]
ax.legend(handles=h, loc="lower right", fontsize=6.8, frameon=False)
ax.set_title("$M_L$ is carried by drug-responsive genes, not by library identity", loc="left", fontsize=9.5, color=C["ink"])
fig.text(0.01, 0.01, "Same cells, thinning (3000 UMIs), held-out evaluation cells and residual model as the main analysis; seed 0.\n"
         "Random panels: median of 20 (200 genes) or 40 (11 genes) draws. Drug-stable panel selected on fit cells only (max |log2FC| vs day 0 = 0.78).\n"
         "Points below 0.3 drawn at 0.3.", fontsize=5.6, color=C["ink2"])
fig.tight_layout(rect=(0, 0.08, 1, 1)); fig.savefig(FIG / "gene_panel_control.png"); fig.savefig(FIG / "gene_panel_control.pdf")
