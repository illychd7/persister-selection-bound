#!/usr/bin/env python3
"""Appendix C: rejection rates of H_SC per method and scenario (single-sample benchmark)."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import json, numpy as np, pandas as pd
from config import RES
df = pd.DataFrame(json.load(open(RES / "benchmark_results.json")))
rules = {
 "ours (M_L, adjusted)": lambda r: r.ours > r.B, "ours unadjusted": lambda r: r.ours_unadj > r.B,
 "classifier ratio, max": lambda r: r.clf_ratio_max > r.B, "classifier ratio, q99": lambda r: r.clf_ratio_q99 > r.B,
 "C2ST (p<0.05)": lambda r: r.c2st_p < 0.05, "MELD ratio, max": lambda r: r.meld_max > r.B, "MELD ratio, q99": lambda r: r.meld_q99 > r.B,
 "Milo-like, max sig. FC": lambda r: r.milo_sig_max > r.B, "UOT growth, max": lambda r: r.uot_max > r.B, "UOT growth, q99": lambda r: r.uot_q99 > r.B,
}
tab = pd.DataFrame({sc: {m: float(np.mean([f(r) for _, r in g.iterrows()])) for m, f in rules.items()} for sc, g in df.groupby("scenario")})
tab = tab[sorted(tab.columns)]; tab.to_csv(RES / "rejection_rates.csv")
print((20 * tab).round(0).astype(int).to_string())
S = pd.DataFrame(json.load(open(RES / "sensitivity.json"))); cols = [c for c in S.columns if c.startswith(("meld", "uot", "milo"))]
print((100 * pd.DataFrame({sc: {c: float((g[c] > g.B).mean()) for c in cols} for sc, g in S.groupby("scenario")})).round(0).to_string())
