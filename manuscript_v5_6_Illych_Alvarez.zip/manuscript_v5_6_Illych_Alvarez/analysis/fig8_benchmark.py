"""Figure 8 (v5.6): response-adjusted bound vs official Milo (pertpy 1.4.0, 3+3 replicates).
(A) Rejections of H_SC per scenario (counts out of 20). (B) Milo neighbourhood size k."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from config import RAW, PROC, DERIVED, RES, FIG, PC9_META, POOLED_META
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
C = dict(o="#eb6834", r="#e34948", p="#b9b7b0", ink="#0b0b0b", ink2="#52514e", grid="#e4e3df", shade="#f1f0ec")
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7.5, "axes.edgecolor": C["ink2"], "xtick.color": C["ink2"], "ytick.color": C["ink2"],
                     "axes.titlesize": 8.5, "axes.titlelocation": "left", "pdf.fonttype": 42})
M = pd.DataFrame(json.load(open(RES / "milo_official_results.json")))
M["bound"] = M.ours > M.B; M["milo_fc"] = M.milo_sig_max > M.B; M["milo_da"] = M.milo_frac_sig > 0
order = ["N1 selection only", "N2 selection + common", "N3 strong selection + common", "A1 + clone-intrinsic 5%", "A2 + clone-intrinsic 30%",
         "A3 + state-dependent 30%", "A4 + cell-level heterogeneity"]
lab = ["selection\nonly", "selection +\ncommon", "strong sel. +\ncommon", "clone-\nintrinsic 5%", "clone-\nintrinsic 30%", "state-\ndependent 30%", "cell-level\nheterogeneity"]
cnt = M.groupby("scenario")[["bound", "milo_fc", "milo_da"]].sum().loc[order]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(10.2, 3.5), dpi=200, gridspec_kw=dict(width_ratios=[2.5, 1]))
for ax in (a1, a2):
    for s in ["top", "right"]: ax.spines[s].set_visible(False)
x = np.arange(len(order)); w = 0.26
a1.axvspan(-.5, 2.5, color=C["shade"], lw=0, zorder=0)
for i, (col, name, c) in enumerate([("bound", "Response-adjusted bound: $M_L > B$", C["o"]), ("milo_fc", "Milo: significant fold change $> B$", C["r"]),
                                    ("milo_da", "Milo: any significant neighbourhood", C["p"])]):
    v = cnt[col].values; a1.bar(x + (i - 1) * w, v, w, color=c, label=name, edgecolor="white", lw=.4, zorder=2)
    for xi, vi in zip(x + (i - 1) * w, v): a1.text(xi, vi + .3, str(int(vi)), ha="center", fontsize=5.6, color=C["ink2"])
a1.text(1, 23.2, "$H_{SC}$ true", ha="center", fontsize=7, color=C["ink2"]); a1.text(4.5, 23.2, "$H_{SC}$ false", ha="center", fontsize=7, color=C["ink2"])
a1.set_xticks(x, lab, fontsize=6.4); a1.set_ylim(0, 24.5); a1.set_yticks([0, 5, 10, 15, 20]); a1.set_xlim(-.5, len(order) - .5)
a1.set_ylabel("Replicates (out of 20)"); a1.grid(axis="y", color=C["grid"], lw=.5); a1.set_axisbelow(True)
a1.legend(fontsize=6.2, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=3)
a1.set_title("A  Decisions per scenario (20 replicates, 3 + 3 replicate samples)")
S = pd.DataFrame(json.load(open(RES / "milo_official_sensitivity.json"))); S["rej"] = S.milo_sig_max > S.B
pts = {}
for k in [10, 50, 100]:
    n = S[(S.k == k) & (S.scenario == "N2 selection + common")]; a = S[(S.k == k) & (S.scenario == "A2 + clone-intrinsic 30%")]
    pts[k] = (100 * n.rej.mean(), 100 * a.rej.mean(), len(n))
pts[30] = (100 * M[M.scenario == "N2 selection + common"].milo_fc.mean(), 100 * M[M.scenario == "A2 + clone-intrinsic 30%"].milo_fc.mean(), 20)
ks = sorted(pts)
a2.grid(color=C["grid"], lw=.5); a2.set_axisbelow(True)
a2.plot([pts[k][0] for k in ks], [pts[k][1] for k in ks], color=C["r"], lw=.9, zorder=2)
a2.scatter([pts[k][0] for k in ks], [pts[k][1] for k in ks], s=26, color=C["r"], edgecolor="white", lw=.5, zorder=3)
grp = {}
for k in ks: grp.setdefault((pts[k][0], pts[k][1]), []).append(f"k={k} (n={pts[k][2]})")
for (xx, yy), labs in grp.items(): a2.annotate(", ".join(labs), (xx, yy), textcoords="offset points", xytext=(7, -10 if yy > 95 else -3), fontsize=5.8, color=C["ink2"])
bo = (100 * M[M.scenario == "N2 selection + common"].bound.mean(), 100 * M[M.scenario == "A2 + clone-intrinsic 30%"].bound.mean())
a2.scatter([bo[0]], [bo[1]], s=60, marker="D", color=C["o"], edgecolor="white", lw=.6, zorder=4)
a2.annotate("bound (no k; n=20)", (bo[0], bo[1]), textcoords="offset points", xytext=(7, 5), fontsize=5.8, color=C["o"])
a2.set_xlim(-5, 40); a2.set_ylim(-5, 112)
a2.set_xlabel("Rejections under selection + common (%)"); a2.set_ylabel("Rejections, clone-intrinsic 30% (%)")
a2.set_title("B  Milo neighbourhood size")
fig.tight_layout(); fig.savefig(FIG / "fig_benchmark.pdf", bbox_inches="tight"); fig.savefig(FIG / "fig_benchmark.png", bbox_inches="tight")
