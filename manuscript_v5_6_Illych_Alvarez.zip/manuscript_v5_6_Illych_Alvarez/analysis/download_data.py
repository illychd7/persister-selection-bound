#!/usr/bin/env python3
"""Download the four GEO supplementary files of GSE150949 into data/raw/ and verify them.

Usage:  python src/download_data.py               # download from NCBI GEO
        python src/download_data.py --from DIR    # copy files already downloaded into DIR
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import argparse, hashlib, shutil, urllib.request
from config import RAW

BASE = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE150nnn/GSE150949/suppl/"
FILES = {  # name: md5 of the files used for the manuscript
    "GSE150949_pc9_count_matrix.csv.gz": "41aceda5a71f0aa8cf646da8e96f94a7",
    "GSE150949_metaData_with_lineage.txt.gz": "0b2e3a828a227f75a1d95dae392a3481",
    "GSE150949_pooled_watermelon.count.matrix.csv.gz": "d181a15a91c197df92def7e735f87224",
    "GSE150949_pooled_watermelon.metadata.matrix.csv.gz": "94375c8a0644982905c57a3cf4417289",
}

def md5(p):
    h = hashlib.md5()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""): h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--from", dest="src", default=None, help="folder with the GEO files already downloaded")
    a = ap.parse_args()
    for name, ref in FILES.items():
        dst = RAW / name
        if not dst.exists():
            if a.src:
                cand = [p for p in pathlib.Path(a.src).iterdir() if p.name.replace("_csv.gz", ".csv.gz").replace("watermelon_count_matrix", "watermelon.count.matrix") == name or p.name == name]
                if not cand: sys.exit(f"{name} not found in {a.src}")
                shutil.copy(cand[0], dst)
            else:
                print("downloading", name, flush=True); urllib.request.urlretrieve(BASE + name, dst)
        got = md5(dst)
        print(f"{name}: {'OK' if got == ref else 'WARNING md5 ' + got + ' differs from ' + ref}")

if __name__ == "__main__":
    main()
