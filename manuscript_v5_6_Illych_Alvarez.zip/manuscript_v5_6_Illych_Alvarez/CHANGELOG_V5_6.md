# v5.6 - revision of v5.5 (writing, definitions, repetitions, errors)

## Errors corrected
- Milo neighbourhood-size sensitivity: k = 10, 50, 100 were run with 10 replicates (k = 30 with 20).
  v5.5 reported "20/20, 20/20, 18/20, 6/20" and "0/20 null replicates for every k". Correct:
  10/10, 20/20, 9/10, 3/10; 0/10, 0/20, 0/10, 0/10 null exceedances. Figure 8 panel B now shows n.
- Figure 8 (v5.5) had overlapping legend text and hid the k = 30 point; redrawn (analysis/fig8_benchmark.py).
- Proxy budget definition: dead lineages count as zero (v5.5 said "d_i = 0 contribution", i.e. 2^0 = 1).
- Pertpy citation: Nat. Methods 23 (2026), 350-359.
- Unadjusted-bound sentence in the benchmark now states that it comes from the single-sample datasets.
- Figure 6: removed the internal reference "as manuscript v4.2" and the label "Manuscript space".

## Definitions added
- Notation subsection: P(X), mu K for a Markov kernel, push-forward f_#, W_p, mu_0 / nu_t.
- D_inf named (Renyi divergence of order infinity); M_sel called "strength of selection"; M_L defined.
- Named hypotheses H_S (pure selection) and H_SC (selection + shared response), used throughout.
- FIT/EVAL split, Watermelon, Ex2/Ex3, DA, OT+KNN, d and d_i in the survival budget, B (budget).
- Symbol clashes removed: B was budget, tail set and proof constant; tail sets are now T, proof constants a, b.
  mu_t / nu_t unified to nu_t.

## Repetition and style
- Abstract shortened to 145 words (Cell Systems Summary format, about 150 words).
- The tagline "Clonal fate is selected; transcriptional state is induced" kept once in the Discussion
  (plus the title); duplicated sentences between Abstract, Results, Section 5, Discussion and Limitations removed.
- Jargon reduced ("mechanism-specific wrapper", "effect-budget wrapper", "operating regimes").
- References to earlier versions removed ("our earlier pipeline", "the original snapshot analysis").
- Other comparators (classifier ratio, C2ST, MELD, unbalanced OT, neighbourhood test) now have a table
  (Appendix C); v5.5 described them in Methods without reporting their results.

## Citations added
Clopper-Pearson (1934), Lause et al. (2021), Muzellec et al. (2023, PyDESeq2), Lopez-Paz & Oquab (2017, C2ST),
Flamary et al. (2021, POT), Oren et al. bioRxiv (2020, source of the digitised figure).

## Still to be completed by the author (red notes in the PDF)
- Methods of the known-response simulation (Fig. 1).
- Repository/DOI, acknowledgments and funding, declaration of interests,
  declaration of generative AI use (required by Cell Press).
