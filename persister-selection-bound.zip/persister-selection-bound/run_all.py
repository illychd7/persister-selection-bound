#!/usr/bin/env python3
"""Reproduce every number, table and figure of the manuscript.

  python run_all.py                     # full pipeline (downloads GEO data)
  python run_all.py --from DIR          # use GEO files already downloaded into DIR
  python run_all.py --skip-benchmark    # skip the semi-synthetic benchmarks (about 1 h of the runtime)
  python run_all.py --only main_table fig8   # run selected steps
"""
import argparse, subprocess, sys, time, pathlib
ROOT = pathlib.Path(__file__).resolve().parent; SRC = ROOT / "src"; PROC = ROOT / "data" / "processed"
STEPS = [  # (name, script arguments, part of benchmark)
    ("download", ["download_data.py"], False),
    ("sparse_pc9", ["to_sparse.py", "data/raw/GSE150949_pc9_count_matrix.csv.gz", "data/processed/pc9"], False),
    ("sparse_pooled", ["to_sparse.py", "data/raw/GSE150949_pooled_watermelon.count.matrix.csv.gz", "data/processed/pooled"], False),
    ("preprocess_pc9", ["pc9_preprocess_keep.py"], False),
    ("main_table", ["main_table.py"], False),
    ("survival_budget", ["survival_budget.py"], False),
    ("gene_panels", ["gene_panel_control.py"], False),
    ("panel_direction", ["panel_direction_check.py"], False),
    ("fig_panels", ["control_figure.py"], False),
    ("fig_directionality", ["fig_directionality.py"], False),
    ("clone_decomposition", ["run_real.py"], False),
    ("semisynthetic", ["semisynthetic.py"], False),
    ("dispersion", ["dispersion_check.py"], False),
    ("within_between", ["within_vs_between.py"], False),
    ("fate", ["fate_predictability.py"], False),
    ("pooled_lines", ["pooled_decomp.py"], False),
    ("crossfit_ceiling", ["crossfit_ceiling.py"], False),
    ("benchmark", ["benchmark.py", "20"], True),
    ("benchmark_sensitivity", ["sensitivity.py"], True),
    ("benchmark_summary", ["benchmark_summary.py"], True),
    ("milo", ["bench_milo.py", "main", "20"], True),
    ("milo_sensitivity", ["bench_milo.py", "sens", "10"], True),
    ("fig8", ["fig8_benchmark.py"], True),
    ("figures", ["make_figs.py"], False),
    ("check", ["check_results.py"], False),
]
ap = argparse.ArgumentParser()
ap.add_argument("--from", dest="src", default=None); ap.add_argument("--skip-benchmark", action="store_true"); ap.add_argument("--only", nargs="*")
a = ap.parse_args()
for name, args, bench in STEPS:
    if a.only and name not in a.only: continue
    if a.skip_benchmark and bench: continue
    cmd = [sys.executable, str(SRC / args[0])] + args[1:]
    if name == "download" and a.src: cmd += ["--from", a.src]
    if name.startswith("sparse") and (PROC / (args[2].split("/")[-1] + "_counts.npz")).exists() and not a.only:
        print(f"[skip] {name}: already converted"); continue
    t = time.time(); print(f"\n=== {name} ===", flush=True)
    r = subprocess.run(cmd, cwd=ROOT)
    print(f"--- {name}: {'done' if r.returncode == 0 else 'FAILED'} in {time.time() - t:.0f} s", flush=True)
    if r.returncode != 0 and name != "check": sys.exit(r.returncode)
