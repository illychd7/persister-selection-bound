# Response-adjusted selection bounds for single-cell drug tolerance

Code for the manuscript *Fate is selected, state is induced: response-adjusted inference in
single-cell drug tolerance* (I. Alvarez). It reproduces every number, table and figure of the
analyses of GEO series GSE150949 (PC9 time course and pooled Watermelon lines) with fixed
random seeds.

## Quick start

```bash
git clone <repository URL>          # or download and unzip the archive
cd persister-selection-bound
python -m venv .venv && source .venv/bin/activate      # optional
pip install -r requirements.txt
python run_all.py                    # downloads the GEO data and runs everything
```

`run_all.py` downloads four supplementary files of GSE150949 (about 420 MB) from NCBI GEO into
`data/raw/`, checks their MD5 sums, runs all analyses, writes results to `results/` and
figures to `figures/`, and finally compares the regenerated results with the values reported
in the manuscript (stored in `expected/`). The last line of the log is
`All results reproduced.` when every value matches.

Options:

| command | effect |
|---|---|
| `python run_all.py --from DIR` | use GEO files already downloaded into `DIR` |
| `python run_all.py --skip-benchmark` | skip the semi-synthetic benchmarks (about 6 min); the check then reports their files as missing |
| `python run_all.py --only main_table fig8` | run selected steps (names listed in `run_all.py`) |

**Runtime and hardware.** About 15 minutes on a 2-core machine with 8 GB RAM (Linux, Python 3.13),
plus the download. Disk space: about 3 GB.

**Reproducibility.** All results are bit-identical across runs except the MELD-derived density
ratios (benchmark comparator), which vary by less than 2% between runs because of randomised steps
inside MELD/graphtools; no decision changes, and the rejection counts reported in the manuscript
(`results/rejection_rates.csv`) are checked exactly.

## Where each result comes from

| manuscript item | script (in `src/`) | output |
|---|---|---|
| Fig. 1 (known-response simulation) | **to be added by the author** (`src/known_response_simulation.py`) | `results/simulation_response_adjustment.csv` |
| preprocessing (55,801 cells, 3,983 clones) | `to_sparse.py`, `pc9_preprocess_keep.py` | `data/processed/` |
| Table 1, Fig. 3B | `main_table.py` | `results/main_table.json` |
| survival budgets, Fig. 3A | `survival_budget.py` | `results/survival_budget.json` |
| Fig. 2 (semi-synthetic calibration) | `semisynthetic.py` | `results/semisynthetic.json` |
| Fig. 4, Appendix B (clone decomposition) | `run_real.py`, `dispersion_check.py`, `within_vs_between.py`, `fate_predictability.py` | `results/*.json` |
| Fig. 5 (pooled lines) | `pooled_decomp.py` | `results/pooled_decomp.json` |
| Fig. 6 (gene-panel controls) | `gene_panel_control.py`, `control_figure.py` | `results/gene_panel_control.json` |
| Fig. 7 (direction of the statistic) | `panel_direction_check.py`, `fig_directionality.py` | `results/panel_direction_check.json` |
| Fig. 8 (comparison with Milo) | `bench_milo.py`, `fig8_benchmark.py` | `results/milo_official_*.json` |
| Appendix C (other comparators) | `benchmark.py`, `sensitivity.py`, `benchmark_summary.py` | `results/rejection_rates.csv`, `results/sensitivity.json` |
| Appendix A (power ceiling) | `crossfit_ceiling.py` | `results/crossfit_power_ceiling.csv` |
| Figs. 2, 3, 4, 5 (drawing) | `make_figs.py` | `figures/` |

The finite-sample lower bound $M_L$ is implemented in `src/seltest.py` (`lower_bound`,
`lower_bound_mixture`). The clone-level decomposition is in `src/decomposition.py`.

## Inputs shipped with the repository (`data/derived/`)

* `fig1b_digitized.npz` - per-lineage survival and divisions of 1,135 PC9 lineages, digitised
  from Fig. 1b of Oren et al., bioRxiv 2020 (doi:10.1101/2020.06.05.136358). To regenerate it,
  download the preprint PDF, extract the embedded images of page 13
  (`pdfimages -f 13 -l 13 -png preprint.pdf img/p`) and run
  `python src/digitize_fig1b.py img/p-003.png img/p-006.png data/derived/fig1b_digitized.npz`
  (heat map and colour bar). The figure itself is not redistributed.
* `crossfit_response_ot_bounds.csv` - bounds of four response models fitted on training clones
  and evaluated on held-out clones (Appendix A). **Author: add the script that generates this file.**

## Data

All data are public: GEO GSE150949
(<https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE150949>). Files used:
`GSE150949_pc9_count_matrix.csv.gz`, `GSE150949_metaData_with_lineage.txt.gz`,
`GSE150949_pooled_watermelon.count.matrix.csv.gz`,
`GSE150949_pooled_watermelon.metadata.matrix.csv.gz`.

## License

MIT (see `LICENSE`).
